import math
w = 543
tr = w//130
print("Можно отрезать: ", tr)