a = int(input("Введите число: "))

if a>99:
    digitOne = a//100
    digitTwo = a//10%10
    digitThree = a%10
   
    if digitOne == digitTwo == digitThree:
        print("Все числа равны")
    else:
        print("Числа не одинаковые")
else:
    print("Надо ввести 3-х значное число")


