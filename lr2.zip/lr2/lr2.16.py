import math
m = int(input("Введите массу в КГ: "))
t = m//1000
t = math.floor(t)
print("Кол-во тонн:",t)