a = int(input("Введите число: "))
revNum = 0
whDigit = a

if a>99:
    while whDigit != 0:
        digit = whDigit % 10
        revNum = revNum * 10 + digit
        whDigit //= 10

    if a == revNum:
        print("Является палиндромом",revNum, a)
    else:
        print("Не является палиндромом",revNum, a)
else:
    print("Надо ввести 3-х значное число")


